module.exports = {
  devServer: {
    disableHostCheck: true,
  },


  lintOnSave: true,
  runtimeCompiler: true,

  transpileDependencies: [
    'vuetify'
  ]
}
