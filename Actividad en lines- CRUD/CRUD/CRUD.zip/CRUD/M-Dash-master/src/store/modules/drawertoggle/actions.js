
export default {
	drawerOn({ commit }) {
		commit('toggleDrawerState')
	},
}