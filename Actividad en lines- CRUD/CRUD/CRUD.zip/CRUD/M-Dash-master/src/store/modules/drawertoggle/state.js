export default {
	drawerState: false, //controls the side bar "SideDrawer" drawer open/close state
	color: "secondary",
	image: "", //change if you want a picture but if you are using this internally get rid of the picture links here and in filter.vue
};
