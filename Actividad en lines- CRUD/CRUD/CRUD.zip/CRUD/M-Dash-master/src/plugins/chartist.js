import Vue from 'vue'
import 'chartist/dist/chartist.min.css'

// eslint-disable-next-line no-undef
Vue.use(require('vue-chartist'))
